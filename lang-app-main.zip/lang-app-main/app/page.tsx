export { default } from "./landing/page"
